# Kingshot Autopilot — Android

Projeto-fonte Android para Samsung Galaxy A16 / Android 16. Inclui painel local, anotações de recursos, tarefas, captura de tela autorizada por MediaProjection e OCR local com Google ML Kit.

## Compilar APK pela nuvem usando somente o celular

Este projeto já inclui o workflow `.github/workflows/build-apk.yml` para GitHub Actions.

1. No navegador do Samsung, entre em https://github.com e crie um repositório novo chamado `kingshot-autopilot`.
2. Extraia este ZIP no app **Meus Arquivos** do Samsung.
3. Envie o conteúdo da pasta `KingshotAutopilot-Android` para a raiz do repositório, preservando a pasta oculta `.github/workflows`.
4. Se o seletor móvel não permitir enviar a pasta `.github`, crie no GitHub um arquivo novo com o caminho `.github/workflows/build-apk.yml` e copie nele o conteúdo do arquivo de mesmo nome deste ZIP.
5. Faça commit na branch `main`.
6. No GitHub, abra o repositório > **Actions** > **Build Kingshot Autopilot APK** > **Run workflow**.
7. Aguarde o workflow terminar com marca verde. Abra a execução concluída e baixe **Artifacts** > `kingshot-autopilot-debug-apk`.
8. Extraia o ZIP do artifact. Dentro dele estará `app-debug.apk`. Toque nele para instalar. Se o Android pedir, autorize instalação pelo navegador ou pelo app Meus Arquivos.

## O que o workflow faz

Usa um runner Ubuntu hospedado pelo GitHub, instala Java 17, Gradle 8.11.1 e Android SDK 36, executa `assembleDebug` e publica o APK como artifact por 7 dias. Não exige Mac ou computador local. O GitHub pode exigir conta e autenticação; limites de minutos e armazenamento dependem do plano e das configurações da conta.

## Abrir e compilar localmente
1. Extraia o ZIP.
2. Abra a pasta `KingshotAutopilot-Android` no Android Studio.
3. Aguarde a sincronização do Gradle.
4. Execute no Galaxy A16 ou gere APK em **Build > Build APK(s)**.

## Como usar
1. Abra o app.
2. Toque em **Iniciar captura** e aceite a janela de captura do Android.
3. Mantenha Kingshot visível. O OCR atualiza o texto reconhecido periodicamente.
4. Pare a captura pelo botão **Parar**.

## Limitações desta versão
- É um MVP de monitoramento visual: OCR retorna texto bruto; ainda não classifica automaticamente recursos, rallies, equipamentos ou relatórios de batalha.
- Não executa toques no Kingshot nem rotinas que joguem automaticamente.
- A captura depende da autorização explícita do Android e pode ser encerrada pelo sistema ou pelo usuário.
- Temporizadores são registrados localmente; notificações de conclusão e execução em segundo plano ainda não estão implementadas.
- O código foi preparado para compilação em nuvem, mas o APK ainda precisa ser gerado por uma execução bem-sucedida do GitHub Actions. Não foi testado em dispositivo real.

## Privacidade
A captura é processada no dispositivo por ML Kit. O app não envia imagens para servidor próprio e não acessa APIs, banco de dados ou arquivos internos do jogo.
