package com.kingshot.autopilot

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                AutopilotScreen(
                    context = this,
                    onStartCapture = { code, data ->
                        val i = Intent(this, ScreenMonitorService::class.java).apply {
                            action = ScreenMonitorService.ACTION_START
                            putExtra(ScreenMonitorService.EXTRA_RESULT_CODE, code)
                            putExtra(ScreenMonitorService.EXTRA_DATA, data)
                        }
                        startForegroundService(i)
                    },
                    onStopCapture = {
                        startService(Intent(this, ScreenMonitorService::class.java).apply {
                            action = ScreenMonitorService.ACTION_STOP
                        })
                    }
                )
            }
        }
    }
}

@Composable
private fun AutopilotScreen(
    context: Context,
    onStartCapture: (Int, Intent) -> Unit,
    onStopCapture: () -> Unit
) {
    val projectionManager = remember {
        context.getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
    }
    var latestText by remember { mutableStateOf("Aguardando captura autorizada da tela.") }
    var running by remember { mutableStateOf(false) }
    var resources by remember { mutableStateOf(loadResources(context)) }
    var task by remember { mutableStateOf("") }
    var tasks by remember { mutableStateOf(loadTasks(context)) }
    var timerMinutes by remember { mutableStateOf("15") }
    var timerLabel by remember { mutableStateOf("Construção") }
    var timerStatus by remember { mutableStateOf("Nenhum temporizador ativo") }

    val captureLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK && result.data != null) {
            onStartCapture(result.resultCode, result.data!!)
            running = true
        }
    }

    LaunchedEffect(Unit) {
        while (true) {
            latestText = context.getSharedPreferences("autopilot", Context.MODE_PRIVATE)
                .getString("latest_ocr", latestText) ?: latestText
            running = context.getSharedPreferences("autopilot", Context.MODE_PRIVATE)
                .getBoolean("capture_running", running)
            delay(1200)
        }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text("KINGSHOT AUTOPILOT", style = MaterialTheme.typography.headlineSmall)
            Text("Assistente visual local • Galaxy A16 / Android 16")
        }
        item {
            Card(shape = RoundedCornerShape(18.dp)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Monitoramento visual", style = MaterialTheme.typography.titleLarge)
                    Text(if (running) "Captura ativa" else "Captura parada")
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { captureLauncher.launch(projectionManager.createScreenCaptureIntent()) }) {
                            Text("Iniciar captura")
                        }
                        OutlinedButton(onClick = {
                            onStopCapture()
                            running = false
                        }) { Text("Parar") }
                    }
                    Text("Texto reconhecido (OCR)", style = MaterialTheme.typography.titleMedium)
                    Text(latestText.take(5000))
                }
            }
        }
        item {
            Card(shape = RoundedCornerShape(18.dp)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Recursos — anotações locais", style = MaterialTheme.typography.titleLarge)
                    listOf("Gemas", "Comida", "Madeira", "Pedra").forEach { name ->
                        OutlinedTextField(
                            value = resources[name] ?: "",
                            onValueChange = { value ->
                                resources = resources.toMutableMap().apply { put(name, value) }
                                saveResources(context, resources)
                            },
                            label = { Text(name) },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )
                    }
                }
            }
        }
        item {
            Card(shape = RoundedCornerShape(18.dp)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Temporizador local", style = MaterialTheme.typography.titleLarge)
                    OutlinedTextField(timerLabel, { timerLabel = it }, label = { Text("Atividade") }, singleLine = true)
                    OutlinedTextField(timerMinutes, { timerMinutes = it.filter(Char::isDigit) },
                        label = { Text("Duração em minutos") }, singleLine = true)
                    Button(onClick = {
                        val minutes = timerMinutes.toLongOrNull()?.coerceIn(1, 10080) ?: 15
                        val end = System.currentTimeMillis() + minutes * 60_000
                        context.getSharedPreferences("autopilot", Context.MODE_PRIVATE).edit()
                            .putLong("timer_end", end).putString("timer_label", timerLabel).apply()
                        timerStatus = "$timerLabel: alerta em $minutes min"
                    }) { Text("Iniciar temporizador") }
                    Text(timerStatus)
                }
            }
        }
        item {
            Card(shape = RoundedCornerShape(18.dp)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Tarefas", style = MaterialTheme.typography.titleLarge)
                    OutlinedTextField(task, { task = it }, label = { Text("Nova tarefa") }, modifier = Modifier.fillMaxWidth())
                    Button(onClick = {
                        if (task.isNotBlank()) {
                            tasks = tasks + task.trim()
                            saveTasks(context, tasks)
                            task = ""
                        }
                    }) { Text("Adicionar tarefa") }
                }
            }
        }
        items(tasks) { item ->
            var checked by remember(item) { mutableStateOf(false) }
            Card {
                Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                    Row(Modifier.weight(1f)) {
                        Checkbox(checked, { checked = it })
                        Text(item, modifier = Modifier.padding(top = 12.dp))
                    }
                    TextButton(onClick = {
                        tasks = tasks.filterNot { it == item }
                        saveTasks(context, tasks)
                    }) { Text("Excluir") }
                }
            }
        }
        item {
            Text(
                "Segurança: a captura exige autorização explícita do Android. O app apenas lê a tela e registra dados localmente; não toca no jogo, não injeta código e não altera dados do Kingshot.",
                style = MaterialTheme.typography.bodySmall
            )
        }
    }
}

private fun loadResources(c: Context): Map<String, String> {
    val p = c.getSharedPreferences("autopilot", Context.MODE_PRIVATE)
    return listOf("Gemas", "Comida", "Madeira", "Pedra").associateWith {
        p.getString("res_$it", "") ?: ""
    }
}
private fun saveResources(c: Context, values: Map<String, String>) {
    val e = c.getSharedPreferences("autopilot", Context.MODE_PRIVATE).edit()
    values.forEach { (k, v) -> e.putString("res_$k", v) }
    e.apply()
}
private fun loadTasks(c: Context): List<String> =
    c.getSharedPreferences("autopilot", Context.MODE_PRIVATE)
        .getStringSet("tasks", emptySet())?.toList() ?: emptyList()
private fun saveTasks(c: Context, tasks: List<String>) {
    c.getSharedPreferences("autopilot", Context.MODE_PRIVATE).edit()
        .putStringSet("tasks", tasks.toSet()).apply()
}
