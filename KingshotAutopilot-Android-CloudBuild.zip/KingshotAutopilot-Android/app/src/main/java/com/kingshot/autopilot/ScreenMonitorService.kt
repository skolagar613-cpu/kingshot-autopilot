package com.kingshot.autopilot

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.util.DisplayMetrics
import android.view.WindowManager
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.util.concurrent.atomic.AtomicBoolean

class ScreenMonitorService : Service() {
    companion object {
        const val ACTION_START = "com.kingshot.autopilot.START"
        const val ACTION_STOP = "com.kingshot.autopilot.STOP"
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_DATA = "result_data"
        private const val CHANNEL_ID = "screen_monitor"
        private const val NOTIFICATION_ID = 4102
    }

    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var thread: HandlerThread? = null
    private var handler: Handler? = null
    private val processing = AtomicBoolean(false)
    private val recognizer by lazy { TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS) }
    private var lastScan = 0L

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> { stopCapture(); stopSelf(); return START_NOT_STICKY }
            ACTION_START -> {
                startForeground(NOTIFICATION_ID, notification())
                val code = intent.getIntExtra(EXTRA_RESULT_CODE, 0)
                @Suppress("DEPRECATION")
                val data = if (Build.VERSION.SDK_INT >= 33)
                    intent.getParcelableExtra(EXTRA_DATA, Intent::class.java)
                else intent.getParcelableExtra(EXTRA_DATA)
                if (data != null) startCapture(code, data)
            }
        }
        return START_NOT_STICKY
    }

    private fun startCapture(code: Int, data: Intent) {
        stopCapture()
        val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = manager.getMediaProjection(code, data)
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        wm.defaultDisplay.getRealMetrics(metrics)
        val width = metrics.widthPixels
        val height = metrics.heightPixels
        val density = metrics.densityDpi
        thread = HandlerThread("KingshotOCR").also { it.start() }
        handler = Handler(thread!!.looper)
        reader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
        reader!!.setOnImageAvailableListener({ r ->
            val now = System.currentTimeMillis()
            if (now - lastScan < 1800 || !processing.compareAndSet(false, true)) {
                r.acquireLatestImage()?.close()
                return@setOnImageAvailableListener
            }
            lastScan = now
            val image = r.acquireLatestImage()
            if (image == null) { processing.set(false); return@setOnImageAvailableListener }
            processImage(image)
        }, handler)
        projection?.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { stopCapture(); stopSelf() }
        }, handler)
        display = projection?.createVirtualDisplay(
            "KingshotAutopilotCapture", width, height, density,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            reader!!.surface, null, handler
        )
        prefs().edit().putBoolean("capture_running", true).putString("latest_ocr", "Captura iniciada. Aguardando leitura...").apply()
    }

    private fun processImage(image: Image) {
        try {
            val bitmap = imageToBitmap(image)
            image.close()
            val input = InputImage.fromBitmap(bitmap, 0)
            recognizer.process(input)
                .addOnSuccessListener { result ->
                    prefs().edit().putString("latest_ocr",
                        result.text.ifBlank { "Nenhum texto reconhecido nesta imagem." }).apply()
                }
                .addOnFailureListener { e ->
                    prefs().edit().putString("latest_ocr", "Falha no OCR: ${e.localizedMessage}").apply()
                }
                .addOnCompleteListener {
                    bitmap.recycle()
                    processing.set(false)
                }
        } catch (e: Exception) {
            try { image.close() } catch (_: Exception) {}
            prefs().edit().putString("latest_ocr", "Erro na captura: ${e.localizedMessage}").apply()
            processing.set(false)
        }
    }

    private fun imageToBitmap(image: Image): Bitmap {
        val plane = image.planes[0]
        val buffer = plane.buffer
        val pixelStride = plane.pixelStride
        val rowStride = plane.rowStride
        val rowPadding = rowStride - pixelStride * image.width
        val paddedWidth = image.width + rowPadding / pixelStride
        val full = Bitmap.createBitmap(paddedWidth, image.height, Bitmap.Config.ARGB_8888)
        full.copyPixelsFromBuffer(buffer)
        val cropped = Bitmap.createBitmap(full, 0, 0, image.width, image.height)
        full.recycle()
        return cropped
    }

    private fun stopCapture() {
        display?.release(); display = null
        reader?.setOnImageAvailableListener(null, null)
        reader?.close(); reader = null
        projection?.stop(); projection = null
        thread?.quitSafely(); thread = null; handler = null
        prefs().edit().putBoolean("capture_running", false).apply()
    }

    private fun prefs() = getSharedPreferences("autopilot", Context.MODE_PRIVATE)

    private fun notification(): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel(
                CHANNEL_ID, "Monitoramento Kingshot", NotificationManager.IMPORTANCE_LOW
            ))
        }
        return if (Build.VERSION.SDK_INT >= 26) {
            Notification.Builder(this, CHANNEL_ID)
                .setContentTitle("Kingshot Autopilot")
                .setContentText("Monitoramento de tela ativo")
                .setSmallIcon(android.R.drawable.ic_menu_view)
                .setOngoing(true).build()
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
                .setContentTitle("Kingshot Autopilot")
                .setContentText("Monitoramento de tela ativo")
                .setSmallIcon(android.R.drawable.ic_menu_view)
                .setOngoing(true).build()
        }
    }

    override fun onDestroy() {
        stopCapture()
        recognizer.close()
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
}
